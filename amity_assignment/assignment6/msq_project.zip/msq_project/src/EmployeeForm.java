import javax.swing.*;
import java.awt.*;

public class EmployeeForm {
    public static void swinngFront()
    {
        SwingUtilities.invokeLater(()->{
            JFrame frame=new JFrame("Employee");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(300,400);
            JPanel panel=new JPanel(new GridLayout(5,2,10,10));
            JLabel Eidtext=new JLabel("Enter your Employee id");
            JTextField Eid=new JTextField();
            JLabel nametext=new JLabel("Enter your name");
            JTextField Name=new JTextField();
            JLabel Departmenttext=new JLabel("Enter your Department");
            JTextField Department=new JTextField();
            JLabel Salarytext=new JLabel("what is your salary");
            JTextField Salary=new JTextField();
            JButton submit=new JButton("SUBMIT");

            panel.add(Eidtext);
            panel.add(Eid);
            panel.add(nametext);
            panel.add(Name);
            panel.add(Departmenttext);
            panel.add(Department);
            panel.add(Salarytext);
            panel.add(Salary);
            panel.add(new JLabel());
            panel.add(submit);
            frame.add(panel);
            JTable t=new JTable();
            JScrollPane scroll=new JScrollPane(t);
            scroll.setVisible(false);
            submit.addActionListener(e->{
                        EmployeeDAO.msqul(Integer.parseInt(Eid.getText()),Name.getText(),Department.getText(),Double.parseDouble(Salary.getText()));
                        t.setModel(EmployeeDAO.getTableModel());
                        scroll.setVisible(true);
                        frame.revalidate();
                        frame.repaint();
                Eid.setText("");
                Name.setText("");
                Department.setText("");
                Salary.setText("");
                    }
            );
            frame.add(panel, BorderLayout.NORTH);
            frame.add(scroll, BorderLayout.CENTER);
            frame.setVisible(true);
        });
    }

    public static void main(String[] args) {
        swinngFront();
    }
}
