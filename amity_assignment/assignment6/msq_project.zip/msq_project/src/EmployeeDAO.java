import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class EmployeeDAO {
    static final String url = "jdbc:mysql://localhost:3306/company_db";
    static final String user = "root";
    static final String password = "*******";

    public static void msqul(int emp_id, String name, String department, double salary) {


        try (Connection con = DriverManager.getConnection(url, user, password);
             PreparedStatement p = con.prepareStatement("INSERT INTO employees values (?,?,?,?)");
        ) {
            p.setInt(1, emp_id);
            p.setString(2, name);
            p.setString(3, department);
            p.setDouble(4, salary);
            p.executeUpdate();
            System.out.println("Connected successfully!");


        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

//    public static void Display() {
//
//        try (Connection con = DriverManager.getConnection(url, user, password);
//             Statement s = con.createStatement();
//             ResultSet r = s.executeQuery("SELECT * FROM employees")) {
//            while (r.next()) {
//                System.out.println(r.getInt(1) + " " + r.getString(2) + " " + r.getString(3) + " " + r.getDouble(4));
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
    public static DefaultTableModel getTableModel() {
        String[] columns = {"Employee ID", "Name", "Department", "Salary"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);

        try (Connection con = DriverManager.getConnection(url, user, password);
             Statement s = con.createStatement();
             ResultSet r = s.executeQuery("SELECT * FROM employees")) {

            while (r.next()) {
                Object[] row = {
                        r.getInt(1),
                        r.getString(2),
                        r.getString(3),
                        r.getDouble(4)
                };
                model.addRow(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return model;
    }
}
