package com.demo;
import java.time.LocalDate;
import java.time.LocalTime;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class feedback extends HttpServlet {
	@Override
	public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{
		LocalDate date = LocalDate.now();
        LocalTime time = LocalTime.now();
    
	String name=req.getParameter("name");
	String feedtype=req.getParameter("feedbacktype");
	String commend=req.getParameter("commend");
	PrintWriter out=res.getWriter();
	out.print("<html>");
	out.print("<head>");
	out.print("</head>");
	out.print("<body>");
	out.print("Thanks You, "+name+" for you feedback!"+"<br>");
	out.print(feedtype+" : "+commend+"<br>");
	out.print("date:"+date+"<br>");
	out.print("time:"+time);
	out.print("</boby>");
	out.print("</html>");
	}
}

